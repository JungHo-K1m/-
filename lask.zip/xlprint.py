import pandas as pd

dp = pd.read_excel('naver_moive_info.xlsx', sheet_name = 'Sheet')
a = dp['정보']
print(a)